package com.g3dsc.Service;

import java.util.List;
import java.util.Optional;

import com.g3dsc.Entity.User;

public interface UserService {

	public List<User> getUser();

	public Optional<User> getUserById(int id);
	
	public User addUser(User user);

	public void updateUser(int id, User user);

	public void deleteUser(int id);
	
}
