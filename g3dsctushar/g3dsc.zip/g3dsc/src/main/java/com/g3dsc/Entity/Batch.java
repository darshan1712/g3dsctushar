package com.g3dsc.Entity;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Batch {
	@Id
	private int batchId;
	private String batchType;
	private String batchPrice;
	private LocalTime batchStartTime;
	private LocalTime batchEndTime;
	private LocalDate batchStartDate ;
	private LocalDate batchEndDate ;
	
	@OneToMany(mappedBy = "batch")
	private List<Comment> comment;
	
	@ManyToMany(fetch=FetchType.LAZY,cascade=CascadeType.ALL, mappedBy="batch")
	private List<User> user;
	
	@ManyToOne
	private Sport sport;
	//sid fk
}
