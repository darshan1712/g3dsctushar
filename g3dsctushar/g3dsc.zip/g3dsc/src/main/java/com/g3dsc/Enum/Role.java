package com.g3dsc.Enum;

public enum Role {
	admin,
	manager,
	customer
}
